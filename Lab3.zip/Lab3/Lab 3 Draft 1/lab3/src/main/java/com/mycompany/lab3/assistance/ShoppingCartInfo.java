/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.assistance;

/**
 *
 * @author student
 */
public class ShoppingCartInfo {
    CustomerInfo customer;
    FoodItemInfo foodItem;
    int CurrentOrderID;
    int quantity;
    double priceForItem;

    public ShoppingCartInfo(CustomerInfo customer, FoodItemInfo foodItem) {
        this.customer = customer;
        this.foodItem = foodItem;
    }

    public ShoppingCartInfo(CustomerInfo customer, FoodItemInfo foodItem, int CurrentOrderID, int quantity, double priceForItem) {
        this.customer = customer;
        this.foodItem = foodItem;
        this.CurrentOrderID = CurrentOrderID;
        this.quantity = quantity;
        this.priceForItem = priceForItem;
    }

    public ShoppingCartInfo(int CurrentOrderID, int quantity, double priceForItem) {
        this.CurrentOrderID = CurrentOrderID;
        this.quantity = quantity;
        this.priceForItem = priceForItem;
    }

    public ShoppingCartInfo(CustomerInfo customer, FoodItemInfo foodItem, int quantity, double priceForItem) {
        this.customer = customer;
        this.foodItem = foodItem;
        this.quantity = quantity;
        this.priceForItem = priceForItem;
    }
    
    public ShoppingCartInfo(CustomerInfo customer, FoodItemInfo foodItem, int quantity) {
        this.customer = customer;
        this.foodItem = foodItem;
        this.quantity = quantity;
        this.priceForItem = priceForItem;
    }

    public ShoppingCartInfo(int CurrentOrderID) {
        this.CurrentOrderID = CurrentOrderID;
    }

    public CustomerInfo getCustomer() {
        return customer;
    }

    public FoodItemInfo getFoodItem() {
        return foodItem;
    }

    public int getCurrentOrderID() {
        return CurrentOrderID;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPriceForItem() {
        return priceForItem;
    }
    
    

}
