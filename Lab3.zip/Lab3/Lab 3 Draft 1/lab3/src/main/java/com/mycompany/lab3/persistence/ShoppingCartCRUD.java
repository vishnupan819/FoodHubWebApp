/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.persistence;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Statement;
import java.util.Enumeration;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
public class ShoppingCartCRUD {
    
    private static Connection getConnection(){
        Connection connection = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/FoodHubSystem?autoReconnect=true&useSSL=false","root","student");
            System.out.println("DB Connection Established");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }
    
    public static ArrayList<ShoppingCartInfo> getShoppingCartInfo(String userName){
        ArrayList<ShoppingCartInfo> cart = new ArrayList<ShoppingCartInfo>();
        CustomerInfo customerInfo = null;
        FoodItemInfo itemInfo = null;
        try{
            Connection connection = getConnection();
            //String query = "select * from Customer where Username='"+userName+"' and Password='"+password+"'";
            
            String query = "select c.Username, c.Password, f.ItemName, s.Quantity, s.TotalPrice " +
                            "from Customer as c " +
                            "join ShoppingCart as s " +
                            "    on (c.CustomerID=s.CustomerID) " +
                            "join FoodItem as f " +
                            "    on (s.FoodItemID=f.FoodItemID) " +
                            "where c.Username ='"+userName+"'";
            
            System.out.println(query);
            
            Statement ps = connection.createStatement();
            ResultSet rs = ps.executeQuery(query);
            while(rs.next()){
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                customerInfo = CustomerCRUD.getCustomerInfo(dbUsername, dbPassword);
                
                String dbItemName = rs.getString("ItemName");
                itemInfo = FoodItemCRUD.getFoodItemInfo(dbItemName);
                
                int dbItemQuantity = rs.getInt("Quantity");
                double dbItemTotalPrice = rs.getDouble("TotalPrice");
                ShoppingCartInfo cartItem = new ShoppingCartInfo(customerInfo,itemInfo,dbItemQuantity,dbItemTotalPrice);
                cart.add(cartItem);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return cart;
    }
    
    public static ShoppingCartInfo getShoppingCartItem(String userName, String foodItemName){
        ShoppingCartInfo item = null;
        CustomerInfo customerInfo = null;
        FoodItemInfo itemInfo = null;
        try{
            Connection connection = getConnection();
            //String query = "select * from Customer where Username='"+userName+"' and Password='"+password+"'";
            
            String query = "select c.Username, c.Password, f.ItemName, s.Quantity " +
                            "from Customer as c " +
                            "join ShoppingCart as s " +
                            "    on (c.CustomerID=s.CustomerID) " +
                            "join FoodItem as f " +
                            "    on (s.FoodItemID=f.FoodItemID) " +
                            "where c.Username ='"+userName+"' and f.ItemName='"+foodItemName+"'";
            
            System.out.println(query);
            
            Statement ps = connection.createStatement();
            ResultSet rs = ps.executeQuery(query);
            if(rs.next()){
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                customerInfo = CustomerCRUD.getCustomerInfo(dbUsername, dbPassword);
                
                String dbItemName = rs.getString("ItemName");
                itemInfo = FoodItemCRUD.getFoodItemInfo(dbItemName);
                
                int dbItemQuantity = rs.getInt("Quantity");
                item = new ShoppingCartInfo(customerInfo,itemInfo,dbItemQuantity,(dbItemQuantity*itemInfo.getPrice()));
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return item;
    }
    
    
    public static int addToCart(CustomerInfo customer, FoodItemInfo foodItem, int quantityToAdd){
        int result = 0;
        try{
            Connection connection = getConnection();
            boolean isPurchasePossible = foodItem.getQuantity()>=quantityToAdd;
            System.out.println(isPurchasePossible);
            if(isPurchasePossible && quantityToAdd>0){
                boolean isItemInCart = false;
                int quantityInCart = 0;
                String query  = "select count(f.FoodItemID) as CountForItem, s.Quantity " +
                                        "from Customer as c " +
                                        "join ShoppingCart as s " +
                                        "    on (c.CustomerID = s.CustomerID) " +
                                        "join FoodItem as f " +
                                        "    on (s.FoodItemID = f.FoodItemID) " +
                                        "where c.Username = '"+customer.getUserName()+"' and f.FoodItemID=" +foodItem.getFoodItemID()+" " +
                                        "group by f.FoodItemID";
                    Statement statement = connection.createStatement();
                    ResultSet rs = statement.executeQuery(query);
                    if(rs.next()){
                        int count = rs.getInt("CountForItem");
                        quantityInCart = rs.getInt("Quantity");
                        if(count==1){
                            isItemInCart = true;
                        }
                    }
                if(isItemInCart){
                    query = "update ShoppingCart set Quantity="+(quantityInCart+quantityToAdd)+", TotalPrice="+((quantityInCart+quantityToAdd)*foodItem.getPrice())+" "+
                            "where CustomerID="+customer.getCustomerID()+" and FoodItemID="+foodItem.getFoodItemID();
                    System.out.println(query);
                    statement = connection.createStatement();
                    result = statement.executeUpdate(query);
                }
                else{
                    query = "insert into ShoppingCart(CustomerID, FoodItemID, Quantity, TotalPrice) values ("+customer.getCustomerID()+","+foodItem.getFoodItemID()+","+quantityToAdd+","+(foodItem.getPrice()*quantityToAdd)+")";
                    System.out.println(query);
                    statement = connection.createStatement();
                    result = statement.executeUpdate(query);
                }
                
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static int removeFromCart(CustomerInfo customer, FoodItemInfo foodItem){
        int result = 0;
        try{
            Connection connection = getConnection();
            String query = "delete from ShoppingCart " +
                           "where CustomerID='"+customer.getCustomerID()+"' and FoodItemID='"+foodItem.getFoodItemID()+"'";
            Statement statement = connection.createStatement();
            statement = connection.createStatement();
            result = statement.executeUpdate(query);
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    
    public static int updateQuantityOfItemInCart(CustomerInfo customer, FoodItemInfo foodItem, int newQuantity){
        int result = 0;
        try{
            Connection connection = getConnection();
            FoodItemInfo foodItemToCheck = FoodItemCRUD.getFoodItemInfo(foodItem.getName());
            int maxQuantity = foodItemToCheck.getQuantity();
            boolean isUpdatePossible = maxQuantity>=newQuantity;
            if(isUpdatePossible){
                String query = "update ShoppingCart " +
                                "    set " +
                                "        Quantity = "+newQuantity+", TotalPrice=" +(newQuantity*foodItemToCheck.getPrice())+ " "+
                                "    where CustomerID="+customer.getCustomerID()+" and FoodItemID="+foodItem.getFoodItemID();
                Statement statement = connection.createStatement();
                statement = connection.createStatement();
                result = statement.executeUpdate(query);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static double getTotalPrice(CustomerInfo customer){
        double price = 0;
        try{
            Connection connection = getConnection();
            String query = "select sum(s.TotalPrice) as TotalPrice " +
                            "from Customer as c " +
                            "join ShoppingCart as s " +
                            "on (c.CustomerID=s.CustomerID) " +
                            "join FoodItem as f " +
                            "on (s.FoodItemID=f.FoodItemID) " +
                            "where c.Username ='"+customer.getUserName()+"'";
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query);
            if(rs.next()){
                price = rs.getDouble("TotalPrice");
                System.out.println("HIHI LOWLOW");
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return price;
    }
    
    public static int orderFromCart(CustomerInfo customer, FoodItemInfo foodItem, int quantity){
        int result = 0;
        try{
            Connection connection = getConnection();
            String query = "delete from ShoppingCart " +
                           "where CustomerID='"+customer.getCustomerID()+"' and FoodItemID='"+foodItem.getFoodItemID()+"'";
            Statement statement = connection.createStatement();
            statement = connection.createStatement();
            result = statement.executeUpdate(query);
            
            query = "update FoodItem set AvailableStock= "+(foodItem.getQuantity()-quantity)+" "+
                           "where FoodItemID='"+foodItem.getFoodItemID()+"'";
            statement = connection.createStatement();
            statement = connection.createStatement();
            result = statement.executeUpdate(query);
            
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
}
