/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;
import com.mycompany.lab3.assistance.*;
import com.mycompany.lab3.persistence.*;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebInitParam;

/**
 *
 * @author student
 */
//@WebServlet(name = "updateUserServlet", urlPatterns = {"/updateUserServlet"})
public class UpdateUserServlet extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        System.out.println("doPost()");
        String findUsertype = (String) request.getParameter("findUserType");
        String findUsername = request.getParameter("findUserName");
        String findPassword = request.getParameter("findPassword");
        
        String userType = (String) request.getParameter("userType");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        
        UserInfo findUserInfo = null;
        UserInfo updatedInfo = null;
        
        int entries = 0;
        
        if(userType.equals(findUsertype)){

            /*System.out.println(findUsertype);
            System.out.println(findUsername);
            System.out.println(findPassword);
            System.out.println(userType);
            System.out.println(firstName);
            System.out.println(lastName);
            System.out.println(username);
            System.out.println(password);*/

            if(findUsertype.equals("customer")){
                findUserInfo = new CustomerInfo(findUsername,findPassword);
                if(CustomerCRUD.doesCustomerExist(findUserInfo)){
                    updatedInfo = new CustomerInfo(firstName,lastName,username,password);
                    entries = CustomerCRUD.updateCustomerInfo(findUserInfo, updatedInfo);
                    System.out.println("callingCustCRUD");
                }
            }
            else if(findUsertype.equals("employee")){
                findUserInfo = new EmployeeInfo(findUsername,findPassword);
                if(EmployeeCRUD.doesEmployeeExist(findUserInfo)){
                    updatedInfo = new EmployeeInfo(firstName,lastName,username,password);
                    entries = EmployeeCRUD.updateEmployeeInfo(findUserInfo, updatedInfo);
                    System.out.println("callingEmpCRUD");
                }
            }
            if(entries!=0){
                //request.setAttribute("message","Welcome to Interservlet Communication " + username);
                //requestDispatcher.forward(request, response);
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.print("<b>"+entries+" "+userType+"s updated</b>");
                out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
            }
            else{
                //requestDispatcher = request.getRequestDispatcher("login.html");
                //requestDispatcher.include(request, response);
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.print("<b>No "+userType+"s updated</b>");
                out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
            }
        }
        else{
            if(findUsertype.equals("customer")){
                findUserInfo = new CustomerInfo(findUsername,findPassword);
                if(CustomerCRUD.doesCustomerExist(findUserInfo)){
                    CustomerInfo customerInDB = CustomerCRUD.getCustomerInfo(findUsername, findPassword);
                    entries = CustomerCRUD.deleteCustomer(findUserInfo);
                    
                    String firstNameInDB = customerInDB.getFirstName();
                    String lastNameInDB = customerInDB.getLastName();
                    String userNameInDB = customerInDB.getUserName();
                    String passwordInDB = customerInDB.getPassword();
                    
                    System.out.println("deleting customer record");
                    updatedInfo = new EmployeeInfo(firstName.equals("")?firstNameInDB:firstName,
                            lastName.equals("")?lastNameInDB:lastName,
                            username.equals("")?userNameInDB:username,
                            password.equals("")?passwordInDB:password);
                    entries = EmployeeCRUD.createEmployee(updatedInfo);
                    System.out.println("adding as employee record");
                }
                else{
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.print("<b>No such customer exists</b>");
                }
            }
            else if(findUsertype.equals("employee")){
                findUserInfo = new EmployeeInfo(findUsername,findPassword);
                if(EmployeeCRUD.doesEmployeeExist(findUserInfo)){
                    EmployeeInfo employeeInDB = EmployeeCRUD.getEmployeeInfo(findUsername, findPassword);
                    entries = EmployeeCRUD.deleteEmployee(findUserInfo);
                    
                    String firstNameInDB = employeeInDB.getFirstName();
                    String lastNameInDB = employeeInDB.getLastName();
                    String userNameInDB = employeeInDB.getUserName();
                    String passwordInDB = employeeInDB.getPassword();
                    
                    System.out.println("deleting employee record");
                    updatedInfo = new CustomerInfo(firstName.equals("")?firstNameInDB:firstName,
                            lastName.equals("")?lastNameInDB:lastName,
                            username.equals("")?userNameInDB:username,
                            password.equals("")?passwordInDB:password);
                    entries = CustomerCRUD.createCustomer(updatedInfo);
                    System.out.println("adding as customer record");
                }
                else{
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.print("<b>No such employee exists</b>");
                }
            }
            if(entries!=0){
                //request.setAttribute("message","Welcome to Interservlet Communication " + username);
                //requestDispatcher.forward(request, response);
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.print("<b>"+entries+" "+userType+"s updated and/or roles switched</b>");
                out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
            }
            else{
                //requestDispatcher = request.getRequestDispatcher("login.html");
                //requestDispatcher.include(request, response);
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.print("<b>No "+userType+"s updated and/or roles switched</b>");
                out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
