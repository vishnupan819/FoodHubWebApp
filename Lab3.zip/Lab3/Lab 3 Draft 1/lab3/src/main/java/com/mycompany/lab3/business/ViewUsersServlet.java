/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;

import com.mycompany.lab3.persistence.*;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
//@WebServlet(name = "viewUsersServlet", urlPatterns = {"/viewUsersServlet"})
public class ViewUsersServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doGet()");
        String userType = (String) request.getParameter("userType");
        
        request.setAttribute("userType", userType);
        
        if(userType.equals("customer")){
            ArrayList<CustomerInfo> users = CustomerCRUD.getAllCustomers();
            request.setAttribute("users", users);
            RequestDispatcher rd= request.getRequestDispatcher("usersList.jsp");
            rd.forward(request, response);
            System.out.println("callingCustCRUD");
        }
        else if(userType.equals("employee")){
            ArrayList<EmployeeInfo> users = EmployeeCRUD.getAllEmployees();
            request.setAttribute("users", users);
            RequestDispatcher rd= request.getRequestDispatcher("usersList.jsp");
            rd.forward(request, response);
            System.out.println("callingEmpCRUD");
        }
        else if(userType.equals("both")){
            ArrayList<CustomerInfo> customers = CustomerCRUD.getAllCustomers();
            ArrayList<EmployeeInfo> employees = EmployeeCRUD.getAllEmployees();
            
            ArrayList<UserInfo> users = new ArrayList<UserInfo>();
            
            for(CustomerInfo customer:customers){
                users.add(customer);
            }
            for(EmployeeInfo employee:employees){
                users.add(employee);
            }
            request.setAttribute("users", users);
            RequestDispatcher rd= request.getRequestDispatcher("usersList.jsp");
            rd.forward(request, response);
            System.out.println("calling both CustCRUD and EmpCRUD");
        } 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
