/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;
import com.mycompany.lab3.assistance.*;
import com.mycompany.lab3.persistence.*;

/*import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.PrintWriter;

import java.util.Enumeration;


import javax.servlet.annotation.WebServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebInitParam;
*/

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
//@WebServlet(name = "loginServlet"/*, urlPatterns = {"/loginServlet"}*/)
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet LoginServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }*/
    
    /*@Override
    public void init(ServletConfig config){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            ServletContext context = config.getServletContext();
            Enumeration<String> parameterNames = context.getInitParameterNames();
            while(parameterNames.hasMoreElements()){
                String eachName = parameterNames.nextElement();
                System.out.println("Context Param Name: " + eachName);
                System.out.println("Context Param Value: " + context.getInitParameter(eachName));
            }
            connection = DriverManager.getConnection(context.getInitParameter("dbUrl"), context.getInitParameter("dbUser"), context.getInitParameter("dbPassword"));
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
            //System.out.println("hello");
        }
        
    }*/

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        System.out.println("doPost()");
        String userType = (String) request.getParameter("userType");
        String username = request.getParameter("userName");
        String password = request.getParameter("password");
        
        UserInfo userInfo = null;
        int type = 0;
        
        //System.out.println(username);
        //System.out.println(password);
        //System.out.println(userType);
        if(userType.equals("customer")){
            userInfo = CustomerCRUD.getCustomerInfo(username, password);
            type = 1;
            System.out.println("callingCustCRUD");
        }
        else if(userType.equals("employee")){
            userInfo = EmployeeCRUD.getEmployeeInfo(username, password);
            type = 2;
            System.out.println("callingEmpCRUD");
        }
        //ResultSet resultSet = statement.executeQuery("select * from "+tableName+" where Username='"+username+"' and Password='"+password+"'");

        RequestDispatcher requestDispatcher = request.getRequestDispatcher("viewItemsServlet");
        //RequestDispatcher requestDispatcher;
        //if(resultSet.next()){
        
        //request.getSession().setAttribute("username", username);
        request.setAttribute("userName", username);
        if(userInfo!=null){
            /*if(type==1){
                request.setAttribute("message","Welcome to Interservlet Communication " + ((CustomerInfo)userInfo).getFirstName());
            }
            else{
                request.setAttribute("message","Welcome to Interservlet Communication " + ((EmployeeInfo)userInfo).getFirstName());
            }*/
            if(type==1){
                request.getSession().setAttribute("userName", username);
                requestDispatcher = request.getRequestDispatcher("viewItemsServlet");
                requestDispatcher.forward(request, response);
            }
            else{
                request.getSession().setAttribute("userName", username);
                requestDispatcher = request.getRequestDispatcher("employeeHome.html");
                requestDispatcher.forward(request, response);
            }
        }
        else{
            requestDispatcher = request.getRequestDispatcher("login.html");
            requestDispatcher.include(request, response);
        }
    }
    
    
    /*public void destroy(){
        try{
            connection.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        
    }*/

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
