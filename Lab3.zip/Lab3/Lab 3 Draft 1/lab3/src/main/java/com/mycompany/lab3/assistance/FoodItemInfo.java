package com.mycompany.lab3.assistance;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author student
 */
public class FoodItemInfo {
    private int foodItemID;
    private String name;
    private String description;
    private String category;
    private String dietaryRest;
    private int calories;
    private double price;
    private int quantity;

    public FoodItemInfo(int foodItemID, String name, String description, String category, String dietaryRest, int calories, double price, int quantity) {
        this.foodItemID = foodItemID;
        this.name = name;
        this.description = description;
        this.category = category;
        this.dietaryRest = dietaryRest;
        this.calories = calories;
        this.price = price;
        this.quantity = quantity;
    }

    public FoodItemInfo(String name) {
        this.name = name;
    }

    public FoodItemInfo(String name, String description, String category, String dietaryRest, int calories, double price, int quantity) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.dietaryRest = dietaryRest;
        this.calories = calories;
        this.price = price;
        this.quantity = quantity;
    }

    public FoodItemInfo(String name, String description, String category, String dietaryRest, int calories, double price) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.dietaryRest = dietaryRest;
        this.calories = calories;
        this.price = price;
    }

    public int getFoodItemID() {
        return foodItemID;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getCategory() {
        return category;
    }

    public String getDietaryRest() {
        return dietaryRest;
    }

    public int getCalories() {
        return calories;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    
}
