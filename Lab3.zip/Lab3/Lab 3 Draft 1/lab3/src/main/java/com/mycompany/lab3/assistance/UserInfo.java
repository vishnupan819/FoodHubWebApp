/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.assistance;

/**
 *
 * @author student
 */
public abstract class UserInfo {
    public abstract String getFirstName();
    public abstract String getLastName();
    public abstract String getUserName();
    public abstract String getPassword();
}
