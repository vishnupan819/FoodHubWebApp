/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.assistance;

/**
 *
 * @author student
 */
public class CustomerInfo extends UserInfo{
    private int customerID;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;
    
    public CustomerInfo(int customerID, String firstName, String lastName, String userName, String password) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
    
    public CustomerInfo(String firstName, String lastName, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
    
    public CustomerInfo(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
    
    public CustomerInfo(String userName) {
        this.userName = userName;
    }

    public int getCustomerID() {
        return customerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}
