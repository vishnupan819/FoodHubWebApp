/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.persistence;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Statement;
import java.util.Enumeration;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author student
 */
public class CustomerCRUD {
    
    private static Connection getConnection(){
        Connection connection = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/FoodHubSystem?autoReconnect=true&useSSL=false","root","student");
            System.out.println("DB Connection Established");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }
    
    public static CustomerInfo getCustomerInfo(String userName, String password){
        CustomerInfo customerInfo = null;
        try{
            Connection connection = getConnection();
            String query = "select * from Customer where Username='"+userName+"' and Password='"+password+"'";
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                int dbCustomerID = rs.getInt("CustomerID");
                String dbFirstName = rs.getString("FirstName");
                String dbLastName = rs.getString("LastName");
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                customerInfo = new CustomerInfo(dbCustomerID,dbFirstName,dbLastName,dbUsername,dbPassword);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return customerInfo;
    }
    
    public static CustomerInfo getCustomerInfo(String userName){
        CustomerInfo customerInfo = null;
        try{
            Connection connection = getConnection();
            String query = "select * from Customer where Username='"+userName+"'";
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                int dbCustomerID = rs.getInt("CustomerID");
                String dbFirstName = rs.getString("FirstName");
                String dbLastName = rs.getString("LastName");
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                customerInfo = new CustomerInfo(dbCustomerID,dbFirstName,dbLastName,dbUsername,dbPassword);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return customerInfo;
    }
    
    
    
    public static int createCustomer(UserInfo userInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            CustomerInfo customerInfo = (CustomerInfo)userInfo;
            String firstName = customerInfo.getFirstName();
            String lastName = customerInfo.getLastName();
            String userName = customerInfo.getUserName();
            String password = customerInfo.getPassword();
            String query = "insert into Customer(FirstName, LastName, Username, Password) values('"+firstName+"','"+lastName+"','"+userName+"','"+password+"')";
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
                    
                    
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/
                    
                    
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static int deleteCustomer(UserInfo userInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            CustomerInfo customerInfo = (CustomerInfo)userInfo;
            String userName = customerInfo.getUserName();
            String password = customerInfo.getPassword();
            String query = "delete from Customer where Username='"+userName+"' and Password='"+password+"'";
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
                    
                    
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/
                    
                    
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static boolean doesCustomerExist(UserInfo userInfo){
        boolean exists = false;
        try{
            Connection connection = getConnection();
            CustomerInfo customerInfo = (CustomerInfo)userInfo;
            String userName = customerInfo.getUserName();
            String password = customerInfo.getPassword();
            String query = "select * from Customer where Username='"+userName+"' and Password='"+password+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            if(rs.next()){
                exists = true;
                System.out.println("exists");
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return exists;
    }
    
    public static int updateCustomerInfo(UserInfo userToBeUpdated, UserInfo updatedInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            CustomerInfo userToBeUpdatedInfo = (CustomerInfo)userToBeUpdated;
            CustomerInfo updateCustomerInfo = (CustomerInfo)updatedInfo;
            
            String findUsername = userToBeUpdatedInfo.getUserName();
            String findPassword = userToBeUpdatedInfo.getPassword();
            
            String firstName = updateCustomerInfo.getFirstName();
            String lastName = updateCustomerInfo.getLastName();
            String userName = updateCustomerInfo.getUserName();
            String password = updateCustomerInfo.getPassword();
            
            String query = "update Customer set "+(firstName.equals("")?"":"FirstName='"+firstName+"',")+(lastName.equals("")?"":"LastName='"+lastName+"',")+(userName.equals("")?"":"Username='"+userName+"',")+(password.equals("")?"":"Password='"+password+"',")+"CustomerID="+(getCustomerInfo(findUsername,findPassword)).getCustomerID()+ " where Username='"+findUsername+"' and Password='"+findPassword+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
            System.out.println(result);
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/
                
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static ArrayList<CustomerInfo> getAllCustomers(){
        ArrayList<CustomerInfo> customers = new ArrayList<CustomerInfo>();
        try{
            Connection connection = getConnection();
            String query = "select * from Customer";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            while(rs.next()){
                int dbCustomerID = rs.getInt("CustomerID");
                String dbFirstName = rs.getString("FirstName");
                String dbLastName = rs.getString("LastName");
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                CustomerInfo customerInfo = new CustomerInfo(dbCustomerID,dbFirstName,dbLastName,dbUsername,dbPassword);
                customers.add(customerInfo);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return customers;
    }
}
