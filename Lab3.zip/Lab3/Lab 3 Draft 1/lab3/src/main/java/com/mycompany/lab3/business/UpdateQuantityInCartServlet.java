/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;

import com.mycompany.lab3.persistence.*;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
//@WebServlet(name = "updateQuantityInCartServlet", urlPatterns = {"/updateQuantityInCartServlet"})
public class UpdateQuantityInCartServlet extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int entries = 0;
        System.out.println("doPost()");
        String userName = (String)request.getSession().getAttribute("userName");
        System.out.println(userName);
        String itemName = (String)request.getParameter("itemName").replace('-', ' ');
        System.out.println(itemName);
        int newQuantity = Integer.parseInt(request.getParameter("itemQuantity"));
        System.out.println(newQuantity);
        
        CustomerInfo customer = CustomerCRUD.getCustomerInfo(userName);
        FoodItemInfo foodItem = FoodItemCRUD.getFoodItemInfo(itemName);
        
        entries = ShoppingCartCRUD.updateQuantityOfItemInCart(customer, foodItem, newQuantity);
        request.getSession().setAttribute("userName", userName);
        ArrayList<ShoppingCartInfo> cartItems = ShoppingCartCRUD.getShoppingCartInfo(userName);
       
        /*for(ShoppingCartInfo item:cartItems){
            System.out.println("Price for item is " + item.getPriceForItem());
        }*/
        double price = ShoppingCartCRUD.getTotalPrice(customer);
        
        System.out.println("Price is " + price);
        
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("price", price);
        
        RequestDispatcher rd= request.getRequestDispatcher("shoppingCart.jsp");
        rd.forward(request, response);
        System.out.println("callingShoppingCartCRUD");
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
