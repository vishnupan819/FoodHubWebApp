/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;

import com.mycompany.lab3.persistence.*;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author student
 */
//@WebServlet(name = "viewShoppingCartServlet", urlPatterns = {"/viewShoppingCartServlet"})
public class ViewShoppingCartServlet extends HttpServlet {
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doGet()");
        
        String userName = (String)request.getSession().getAttribute("userName");
        
        System.out.println(userName);
        request.getSession().setAttribute("userName", userName);
        
        ArrayList<ShoppingCartInfo> cartItems = ShoppingCartCRUD.getShoppingCartInfo(userName);
        
        double price = ShoppingCartCRUD.getTotalPrice(CustomerCRUD.getCustomerInfo(userName));
        
        System.out.println("Price is " + price);
        
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("price", price);
        
        RequestDispatcher rd= request.getRequestDispatcher("shoppingCart.jsp");
        rd.forward(request, response);
        System.out.println("callingShoppingCartCRUD");
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
