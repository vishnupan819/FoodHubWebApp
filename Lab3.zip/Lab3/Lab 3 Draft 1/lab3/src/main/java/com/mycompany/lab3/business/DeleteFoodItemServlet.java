/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.business;
import com.mycompany.lab3.assistance.*;
import com.mycompany.lab3.persistence.*;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.annotation.WebInitParam;
/**
 *
 * @author student
 */
//@WebServlet(name = "deleteFoodItemServlet", urlPatterns = {"/deleteFoodItemServlet"})
public class DeleteFoodItemServlet extends HttpServlet {

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("doPost()");
        String itemName = (String) request.getParameter("itemName");
        
        FoodItemInfo foodItem = new FoodItemInfo(itemName);
        
        int entries = 0;
        entries = FoodItemCRUD.deleteFoodItem(foodItem);
        
        if(entries!=0){
            //request.setAttribute("message","Welcome to Interservlet Communication " + username);
            //requestDispatcher.forward(request, response);
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.print("<b>"+entries+" items deleted</b>");
            out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
        }
        else{
            //requestDispatcher = request.getRequestDispatcher("login.html");
            //requestDispatcher.include(request, response);
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.print("<b>No items deleted</b>");
            out.print("<form action=\"employeeHome.html\"> <input type=\"submit\" value=\"Employee Home Page\" /> </form>");
        }
        
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
