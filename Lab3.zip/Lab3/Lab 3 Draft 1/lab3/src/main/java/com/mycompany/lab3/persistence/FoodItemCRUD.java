/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.persistence;
import com.mycompany.lab3.assistance.*;

import java.util.ArrayList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Statement;
import java.util.Enumeration;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author student
 */
public class FoodItemCRUD {
    
    private static Connection getConnection(){
        Connection connection = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/FoodHubSystem?autoReconnect=true&useSSL=false","root","student");
            System.out.println("DB Connection Established");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }
    
    public static FoodItemInfo getFoodItemInfo(String itemName){
        FoodItemInfo itemInfo = null;
        try{
            Connection connection = getConnection();
            String query = "select * from FoodItem where ItemName='"+itemName+"'";
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                int dbItemID = rs.getInt("FoodItemID");
                String dbitemName = rs.getString("ItemName");
                String dbitemDesc = rs.getString("Description");
                String dbCategory = rs.getString("Category");
                String dbdietRest = rs.getString("DietaryRestrictions");
                int dbCal = rs.getInt("Calories");
                double dbPrice = rs.getDouble("Price");
                int dbQuantity = rs.getInt("AvailableStock");
                itemInfo = new FoodItemInfo(dbItemID,dbitemName,dbitemDesc,dbCategory,dbdietRest,dbCal,dbPrice,dbQuantity);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return itemInfo;
    }
    
    public static int createFoodItem(FoodItemInfo foodItem){
        int result = 0;
        try{
            Connection connection = getConnection();
            String name = foodItem.getName();
            String desc = foodItem.getDescription();
            String category = foodItem.getCategory();
            String dietrest = foodItem.getDietaryRest();
            int cal = foodItem.getCalories();
            double price = foodItem.getPrice();
            int quantity = foodItem.getQuantity();
            String query = "insert into FoodItem(ItemName, Description, Category, DietaryRestrictions, Calories, Price, AvailableStock) values(?,?,?,?,?,?,?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            try{
                stmt.setString(1, name);
                stmt.setString(2, desc);
                stmt.setString(3, category);
                stmt.setString(4, dietrest);
                stmt.setInt(5, cal);
                stmt.setDouble(6, price);
                stmt.setInt(7, quantity);
                result += stmt.executeUpdate();
            }
            catch(SQLException e){
                e.printStackTrace();
            }
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/        
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static int deleteFoodItem(FoodItemInfo foodItem){
        int result = 0;
        try{
            Connection connection = getConnection();
            String itemName = foodItem.getName();
            String query = "delete from FoodItem where ItemName='"+itemName+"'";
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
            
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static boolean doesItemExist(FoodItemInfo foodItem){
        boolean exists = false;
        try{
            Connection connection = getConnection();
            String itemName = foodItem.getName();
            String query = "select * from FoodItem where ItemName='"+itemName+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            if(rs.next()){
                exists = true;
                System.out.println("exists");
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return exists;
    }
    
    public static int updateFoodItemInfo(FoodItemInfo findFoodItem, FoodItemInfo updateFoodItem){
        int result = 0;
        try{
            Connection connection = getConnection();
            
            String findName = findFoodItem.getName();
            
            String itemName = updateFoodItem.getName();
            String itemDesc = updateFoodItem.getDescription();
            String itemCategory = updateFoodItem.getCategory();
            String itemDietaryRest = updateFoodItem.getDietaryRest();
            int itemCals = updateFoodItem.getCalories();
            double itemPrice = updateFoodItem.getPrice();
            int itemQuantity = updateFoodItem.getQuantity();
            
            String query = "update FoodItem set "+(itemName.equals("")?"":"ItemName='"+itemName+"',")+(itemDesc.equals("")?"":"Description='"+itemDesc+"',")+(itemCategory.equals("")?"":"Category='"+itemCategory+"',")+(itemDietaryRest.equals("")?"":"DietaryRestrictions='"+itemDietaryRest+"',")+(itemCals==0?"":"Calories="+itemCals+",")+(itemPrice==0.00?"":"Price="+itemPrice+",")+(itemQuantity==0?"":"AvailableStock="+itemQuantity+",")+"FoodItemID="+(getFoodItemInfo(findName)).getFoodItemID()+" where ItemName='"+findName+"'";

            System.out.println(query);
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
            System.out.println(result);
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/
                
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static ArrayList<FoodItemInfo> getAllFoodItems(){
        ArrayList<FoodItemInfo> foodItems = new ArrayList<FoodItemInfo>();
        try{
            Connection connection = getConnection();
            String query = "select distinct ItemName, Description, Category, DietaryRestrictions, Calories, Price, AvailableStock from FoodItem";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            while(rs.next()){
                String dbItemName = rs.getString("ItemName");
                String dbItemDesc = rs.getString("Description");
                String dbCategory = rs.getString("Category");
                String dbDietRest = rs.getString("DietaryRestrictions");
                int dbCalories = rs.getInt("Calories");
                double dbItemPrice = rs.getDouble("Price");
                int dbItemQuantity = rs.getInt("AvailableStock");
                FoodItemInfo foodItem = new FoodItemInfo(dbItemName,dbItemDesc,dbCategory,dbDietRest,dbCalories,dbItemPrice,dbItemQuantity);
                foodItems.add(foodItem);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return foodItems;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
    public static boolean getItemAvailability(String itemName){
        boolean available = false;
        try{
            Connection connection = getConnection();
            String query = "select * from FoodItem where ItemName='"+itemName+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            if(rs.next()){
                exists = true;
                System.out.println("exists");
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return exists;
        
        
    }*/
    
    /*
    public static void setAvailability(String itemName){
        
    }*/
    
    
    
    
}
