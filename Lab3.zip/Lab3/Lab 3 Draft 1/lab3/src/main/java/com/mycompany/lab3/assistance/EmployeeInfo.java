/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.assistance;

/**
 *
 * @author student
 */
public class EmployeeInfo extends UserInfo{
    
    private int EmployeeID;
    private String firstName;
    private String lastName;
    private String userName;
    private String password;

    public EmployeeInfo(int EmployeeID, String firstName, String lastName, String userName, String password) {
        this.EmployeeID = EmployeeID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
    
    public EmployeeInfo(String firstName, String lastName, String userName, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.password = password;
    }
    
    public EmployeeInfo(String userName, String password) {
        this.userName = userName;
        this.password = password;
    }
    
    public EmployeeInfo(String userName) {
        this.userName = userName;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}
