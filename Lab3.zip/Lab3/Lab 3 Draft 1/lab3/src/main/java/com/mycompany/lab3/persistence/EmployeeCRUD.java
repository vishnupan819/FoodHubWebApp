/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lab3.persistence;
import com.mycompany.lab3.assistance.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Statement;
import java.util.Enumeration;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author student
 */
public class EmployeeCRUD {
    
    private static Connection getConnection(){
        Connection connection = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/FoodHubSystem?autoReconnect=true&useSSL=false","root","student");
            System.out.println("DB Connection Established");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return connection;
    }
    
    public static EmployeeInfo getEmployeeInfo(String userName, String password){
        EmployeeInfo employeeInfo = null;
        try{
            Connection connection = getConnection();
            String query = "select * from Employee where Username='"+userName+"' and Password='"+password+"'";
            PreparedStatement ps = connection.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                int dbEmployeeID = rs.getInt("EmployeeID");
                String dbFirstName = rs.getString("FirstName");
                String dbLastName = rs.getString("LastName");
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                employeeInfo = new EmployeeInfo(dbEmployeeID,dbFirstName,dbLastName,dbUsername,dbPassword);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return employeeInfo;
    }
    
    public static int createEmployee(UserInfo userInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            EmployeeInfo employeeInfo = (EmployeeInfo)userInfo;
            String query = "insert into Employee(FirstName, LastName, Username, Password) values(?,?,?,?)";
            PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, employeeInfo.getFirstName());
            ps.setString(2, employeeInfo.getLastName());
            ps.setString(3, employeeInfo.getUserName());
            ps.setString(4, employeeInfo.getPassword());
            result = ps.executeUpdate();
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static int deleteEmployee(UserInfo userInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            EmployeeInfo employeeInfo = (EmployeeInfo)userInfo;
            String userName = employeeInfo.getUserName();
            String password = employeeInfo.getPassword();
            String query = "delete from Employee where Username='"+userName+"' and Password='"+password+"'";
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
            
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static boolean doesEmployeeExist(UserInfo userInfo){
        boolean exists = false;
        try{
            Connection connection = getConnection();
            EmployeeInfo employeeInfo = (EmployeeInfo)userInfo;
            String userName = employeeInfo.getUserName();
            String password = employeeInfo.getPassword();
            String query = "select * from Employee where Username='"+userName+"' and Password='"+password+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            if(rs.next()){
                exists = true;
                System.out.println("exists");
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return exists;
    }
    
    public static int updateEmployeeInfo(UserInfo userToBeUpdated, UserInfo updatedInfo){
        int result = 0;
        try{
            Connection connection = getConnection();
            EmployeeInfo userToBeUpdatedInfo = (EmployeeInfo)userToBeUpdated;
            EmployeeInfo updateEmployeeInfo = (EmployeeInfo)updatedInfo;
            
            String findUsername = userToBeUpdatedInfo.getUserName();
            String findPassword = userToBeUpdatedInfo.getPassword();
            
            String firstName = updateEmployeeInfo.getFirstName();
            String lastName = updateEmployeeInfo.getLastName();
            String userName = updateEmployeeInfo.getUserName();
            String password = updateEmployeeInfo.getPassword();
            
            String query = "update Employee set "+(firstName.equals("")?"":"FirstName='"+firstName+"',")+(lastName.equals("")?"":"LastName='"+lastName+"',")+(userName.equals("")?"":"Username='"+userName+"',")+(password.equals("")?"":"Password='"+password+"',")+"EmployeeID="+(getEmployeeInfo(findUsername,findPassword)).getEmployeeID()+ " where Username='"+findUsername+"' and Password='"+findPassword+"'";
            System.out.println(query);
            Statement statement = connection.createStatement();
            result = statement.executeUpdate(query);
            System.out.println(result);
            /*PreparedStatement ps = connection.prepareStatement(query);
            ps.setString(1, customerInfo.getFirstName());
            ps.setString(2, customerInfo.getLastName());
            ps.setString(3, customerInfo.getUserName());
            ps.setString(4, customerInfo.getPassword());
            result = ps.executeUpdate();*/
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return result;
    }
    
    public static ArrayList<EmployeeInfo> getAllEmployees(){
        ArrayList<EmployeeInfo> employees = new ArrayList<EmployeeInfo>();
        try{
            Connection connection = getConnection();
            String query = "select * from Employee";
            System.out.println(query);
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(query); 
            while(rs.next()){
                int dbEmployeeID = rs.getInt("EmployeeID");
                String dbFirstName = rs.getString("FirstName");
                String dbLastName = rs.getString("LastName");
                String dbUsername = rs.getString("Username");
                String dbPassword = rs.getString("Password");
                EmployeeInfo employeeInfo = new EmployeeInfo(dbEmployeeID,dbFirstName,dbLastName,dbUsername,dbPassword);
                employees.add(employeeInfo);
            }
            connection.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return employees;
    }
}
